--[[
jahanbots
●》 زبان = Lua / نصب بر روی سرور Ubuntu
@jahanbots
https://t.me/jahanbots
 >> جهت مشاهده سورس های بیشتر در کانال های بالا عضو شوید 
@jahanbots
https://t.me/jahanbots
--]]
local config = {}

config.errorlinkfilename = "Error,Please send your file without space in its name!"
config.errorlinkfilecont = "Links cann't read from file!send it again"
config.oklinkfileread = "Links from txt file read and added to waited list!\nCount of Links:"
config.profilechanged = "Tablighati Profile Changed!"
config.savednumeralready = "شمارت ذخیرس که :)"
config.adminsavenumber = " Dear Admin, Your number Saved :)"
config.welcometext = "Hi my friend 😁\n\n✍🏻Thanks to you for choosing us\nBot successfully turned to on!\n\n—first send this command to active bot /config\n—you can see help with /help\n—see information of bot with /info\n—see settings with /settings\n\ngood luck😃\nTablighati version 3.8.1"
config.promotesudo = " User promoted to SUDO"
config.demotesudo = " User Demoted from SUDO"
config.addtoalltext = "It added to All Groups and SuperGroups!"

--//SETTINGS MENU
config.denyall = "🚫"
config.checkall = "✅"
config.setttops = "🖥Tablighati Settings "
config.settingsname = "\n\n🔨 Settings:"
config.settjoin = "\n▪️Auto join : "
config.settfindlink = "\n▫️Find link : "
config.settoklink = "\n▪️Ok link : "
config.settaddcontact = "\n▫️Add contact : "
config.fauto = "\n▪️Auto forward : "
config.groupleftt = "\n▫️Leave basic gp : "
config.leftnamess = "\n▪️Leave forbidden gp : "
config.restricslefts = "\n▫️Leave restric gp : "
config.settmarkread = "\n▪️Mark read : "
config.settaddcontext = "\n▫️Send pm adding : "
config.settsendnumadd = "\n▪️Send number adding : "
config.setttelenot = "\n▫️Get telegram not : "
config.settautoleave = "\n▪️Auto leave : "
config.settfiltergp = "\n▫️Leave filter gp : "
config.settsectext = "\n▪️Pv secretary : "
config.settgetadminlink = "\n▫️Get link sudo : "
config.settgroupsec = "\n▪️Gp secretary : "
config.settfrand = "\n▫️Auto forward random : "
config.autotimer = "\n▪️Auto leave timer : "
config.addleftsett = "\n▫️Add API and leave : "
config.fwdleftsett = "\n▪️Forward and leave : "
config.checkopensett = "\n▫️Leave closed add : "
config.settchannel = "\n▪️Leave Channels : "
config.footersett = "\n\n✍🏻Tablighati version: 3.8.1"
--//END SETTINGS MENU

--//INFO MENU
config.infotop = "🖥Tablighati Information "
config.infoid = "\n▪️Tablighati ID : "
config.infoname = "\n▫️Tablighati name : "
config.infonum = "\n▪️Tablighati number : "
config.infostat = "\n\n💾 Stats:"
config.infosgp = "\n▫️Supergroups : "
config.infogp = "\n▪️Groups : "
config.infocont = "\n▫️Contacts : "
config.infopriv = "\n▪️Private Chats : "
config.infoadmin = "\n▫️Sudos : "
config.infolink = "\n▪️Links : "
config.infowlink = "\n▫️Waiting links : "
config.infojlink = "\n▪️Joining links : "
config.infoslink = "\n▫️Saved links : "
config.infolgps = "\n▪️Restric gps : "
config.inforgps = "\n▫️Removed gps : "
config.infochnums = "\n▪️Channels : "
config.infodoings = "\n\n⏱ Processes:"
config.infomaxgp = "\n▪️Max gps : "
config.infominmem = "\n▫️Min members : "
config.infotimetook = "\n▪️Time to oklink : "
config.infojoinagain = "\n▫️Time to joingp : "
config.infolastdoing = "\n▪️Last process :\n "
--//END INFO MENU

config.setname = "Tablighati Name Changed to "
config.setbio = "Tablighati Bio Changed to "
config.setusername = "Tablighati Username Changed to "
config.setprofilefirst = "Now send your profile photo!"
config.fautoadd = "Added to Tablighati Auto Forward Message List!"
config.fautolist = "Your Auto Forward list:"
config.fautooutlist = "You don't have any posts for forward!"
config.fautorem = "Removed from Tablighati Auto Forward Message List!"
config.setsecfile = "Tablighati Secretary File Seted!"
config.setsectext = "Tablighati Secretary Message Seted!"
config.delfautotime = "Tablighati Auto Forward Time Deleted!"
config.delayjoin = "Delay join seted to "
config.delaycheck = "Delay check seted to "
config.startfaild = "Not Found!"

--//HELP
config.help = [[ 
دستورات جدید همراه بااموزش کامل تصویری در
@TablighatiHelp

لیست جدید دستورات ورژن 3.8 در کانال زیر
@TablighatiHelp38

Tablighati v3.8.1
@jahanbots
]] 
--//END HELP
config.ontext = "Tablighati Status set to Online!"
config.offtext = "Tablighati Status set to Offline for(seconds): "
config.etve = "2-step verification password set up and Enabled!"
config.etvef = "2-step verification password was Enable already!\nplease disable it then set up a new password!"
config.savenumon = "Save Contacts Number Set to ON"
config.savenumoff = "Save Contacts Number Set to OFF"
config.sudogetlinkon = "Get just Sudoes link Set to ON"
config.sudogetlinkoff = "Get just Sudoes link Set to OFF"
config.fautoon = "Tablighati Auto Forward Set to ON"
config.randon = "Tablighati Random Forward Set to ON"
config.fautoaddfaild = "Please set auto forward message first, with repling command #addfauto"
config.fautooff = "Tablighati Auto Forward Set to OFF"
config.randoff = "Tablighati Random Forward Set to OFF"
config.seceron = "Tablighati Secretary Set to ON"
config.secersetfaild = "Please set Secretary message first, with repling command setsecretarymsg"
config.seceroff = "Tablighati Secretary Set to OFF"
config.typefautosgp = "Tablighati Auto forward Type seted to SUPERGROUPS"
config.typefautogp = "Tablighati Auto forward Type seted to GROUPS"
config.typefautosgpgp = "Tablighati Auto forward Type seted to SUPERGROUPS and GROUPS"
config.typefautopv = "Tablighati Auto forward Type seted to PVs"
config.typefautoall = "Tablighati Auto forward Type seted to All"
config.addedcontact = "Contacts Succssesfully Added to Group"
config.telegramnoton = "Status Get Telegram Notification Set to ON"
config.telegramnotoff = "Status Get Telegram Notification Set to OFF"
config.leftnameon = "Status Left from spicail Group Name Set to ON"
config.leftnameoff = "Status Left from spicail Group Name Set to OFF"
config.leftnameclean = "Spicial Names list Cleaned!"
config.fautocleanlist = "Auto forward list Cleaned and Auto forward set to OFF!"
config.addcontactcleanlist = "Add contacts welcome list Cleaned!"
config.filtergpon = "Status Auto Leave from Filterd Groups Set to ON"
config.filtergpoff = "Status Auto Leave from Filterd Groups Set to OFF"
config.grouplefton = "Status Auto Leave from Groups Set to ON"
config.groupleftoff = "Status Auto Leave from Groups Set to OFF"
config.channellefton = "Status Auto Leave from Channels Set to ON"
config.channelleftoff = "Status Auto Leave from Channels Set to OFF"
config.onlinetext = "I'm Just Here :)"
config.joinon = "Status Joining Groups Set to ON"
config.joinoff = "Status Joining Groups Set to OFF"
config.addlefton = "Status Add and left bots Set to ON"
config.addleftoff = "Status Add and left bots Set to OFF" 
config.fwdlefton = "Status Forward and left bot Set to ON"
config.fwdleftoff = "Status Forward and left bot Set to OFF" 
config.checkopenon = "Status left from clesed add Set to ON"
config.checkopenoff = "Status left from clesed add Set to OFF" 
config.resticlefton = "Status Left from Restriced Groups Set to ON"
config.resticleftoff = "Status Left from Restriced Groups Set to OFF" 
config.findlinkon = "Status Find Links Set to ON"
config.findlinkoff = "Status Find Links Set to OFF"
config.oklinkon = "Status Okey waiting Links Set to ON"
config.oklinkoff = "Status Okey waiting Links Set to OFF"
config.autoleaveon = "Status Auto Leave from groups Set to ON"
config.autoleaveoff = "Status Auto Leave from groups Set to OFF"
config.sharenumon = "Status Share Tabi Contact Set to ON"
config.sharenumoff = "Status Share Tabi Contact Set to OFF"
config.markreadon = "Status Mark Read Set to ON"
config.markreadoff = "Status Mark Read Set to OFF"
config.setrealm = "Realm seted for recive telegram notfications!"
config.secertoon = "Secretary for send messages to Groups Set to ON"
config.secertooff = "Secretary for send messages to Groups Set to OFF"
config.delmaxgrouptex = "Max Tabi Groups Deleted"
config.delminmembertex = "Min Tabi Groups Members Deleted"
config.resetlinks = "All Links on server Reseted!"
config.resetslinks = "All Saved Links Reseted!"
config.resetpvs = "All Pvs Chat Reseted!"
config.rangeleftallfaild = "Range is wrong!\nAvailable range:[1-50]\nYour range:"
config.answeraddcontacts = { 
"ادی مرسی اه☺🍒", 
"ادی جیگر بپر پیوی🤤🍉", 
"ادت کردم تیز پیویم باش😑🙄😀", 
"Addi bia pv😆😍", 
"addi tiz sik pv🤓🙄", 
"ادی عشخم بپر پیوی 😉😆😍", 
"ادی پیوی نقطه بنداز😓🤧🎈", 
"ادی بیا پیوی، ادتم باز کن", 
"ادی ، هیع", 
"تو هم اد کردم", 
"تو هم ادی (:", 
"ادت کردم ^_^", 
"شمارت ذخیرس که :)", 
"addi ♥♥", 
"adi amo :))", 
"add :'(", 
} 
return config